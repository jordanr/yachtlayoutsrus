<?php
class LLRestClient {
  public $specifications;

  /**
   * Create the client.
   */
  public function __construct() {
  }

  public function &specifications_get() {
    if (isset($this->specifications)) {
      return $this->specifications;
    }
    return $this->call_method('specifications_get', array());
  }

  public function &specification_get($id) {
    return $this->call_method('specification_get',
        array('id' => $id));
  }
  public function &specification_photos_get($specification_id) {
    return $this->call_method('specification_photos_get',
        array('specification_id' => $specification_id));
  }

  public function &specification_photo_get($specification_id, $id) {
    return $this->call_method('specification_get',
        array('specification_id' => $specification_id, 'id' => $id));
  }

  /* UTILITY FUNCTIONS */

  /**
   * Calls the specified normal GET method with the specified parameters.
   *
   * @param string $method  Name of the method to invoke
   * @param array $params   A map of param names => param values
   *
   */
  public function &call_method($method, $params = array()) {
      $data = $this->do_request($method, $params);
      
      $result = new SimpleXMLElement($data);
      return $result;
  }


  private function &do_request($method, $params) {
        $query_string = $this->gen_params($method, $params);
        // create curl resource
        $ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, 'http://layoutsandlinedrawings.com' . $query_string);

        //return the transfer as a string
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/xml')); 

        // $output contains the output string
        $output = curl_exec($ch);

        // close curl resource to free up system resources
        curl_close($ch);      
        return $output;
  }

  private function &gen_params($method, $array) {
    $query_string = "?method=" . $method;
    foreach($array as $key => $value) {
      $query_string .= "&" . $key . "=" . $value;
    }
    return $query_string;
  }
}
?>
