<?php
include_once 'llapi_php5_restlib.php';

class LL {
  public $api_client;

  public function __construct() {
    $this->api_client = new LLRestClient();
  }
}
?>
