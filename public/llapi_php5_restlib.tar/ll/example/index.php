<?php

// the client library
include_once '../php/ll.php';

$ll = new LL();

$spec = $ll->api_client->specification_get(1);
$photos = $ll->api_client->specification_photos_get(1);
//print print_r($spec);

foreach ($photos->photo as $photo) {
  echo '<img src="' . $photo->thumb . '" alt="photo ' . $photo->id . '"/>';
}
?>

<p>
Specification <?php echo $spec->id ?>
<ul>
 <li> <?php echo $spec->length ?> </li>
 <li> <?php echo $spec->manufacturer?> </li>
 <li> <?php echo $spec->model ?> </li>
 <li> <?php echo $spec->year ?> </li>
</ul>
</p>


<p>
Description:<br/>
<?php echo $spec->description ?>
</p>
